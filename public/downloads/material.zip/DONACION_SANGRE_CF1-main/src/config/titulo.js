module.exports = 'Normatividad en promoción de la donación de sangre'
